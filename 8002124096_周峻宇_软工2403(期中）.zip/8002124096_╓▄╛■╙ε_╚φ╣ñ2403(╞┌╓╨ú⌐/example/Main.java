package org.example;

import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentManagementSystem system = new StudentManagementSystem();

        // 菜单
        while (true) {
            System.out.println("学生管理系统菜单：");
            System.out.println("1. 增加学生");
            System.out.println("2. 删除学生");
            System.out.println("3. 修改学生");
            System.out.println("4. 查询学生");
            System.out.println("5. 排序学生成绩");
            System.out.println("6. 排序学号");
            System.out.println("7. 查看所有学生");
            System.out.println("8. 查看本科生人数");
            System.out.println("9. 查看研究生人数");
            System.out.println("10. 查看总人数");
            System.out.println("11. 按单科成绩排序");
            System.out.println("12. 退出");
            System.out.print("请选择操作：");

            int choice = scanner.nextInt();
            scanner.nextLine(); // 清空输入缓冲区

            switch (choice) {
                case 1:
                    // 增加学生
                    System.out.println("请输入学生类型（1-本科生 2-研究生）：");
                    int type = scanner.nextInt();
                    scanner.nextLine();  // 清空缓冲区

                    System.out.print("学号: ");
                    String studentID = scanner.nextLine();
                    System.out.print("姓名: ");
                    String name = scanner.nextLine();
                    System.out.print("年龄: ");
                    int age = scanner.nextInt();
                    scanner.nextLine();  // 清空缓冲区
                    System.out.print("班级: ");
                    String className = scanner.nextLine();
                    System.out.print("省份: ");
                    String province = scanner.nextLine();
                    System.out.print("城市: ");
                    String city = scanner.nextLine();
                    System.out.print("街道: ");
                    String street = scanner.nextLine();
                    System.out.print("门牌号: ");
                    String doorNo = scanner.nextLine();

                    Address address = new Address(province, city, street, doorNo);

                    // 让用户输入4门成绩
                    System.out.println("请输入4门科目的成绩：");
                    System.out.print("科目1成绩: ");
                    double grade1 = scanner.nextDouble();
                    System.out.print("科目2成绩: ");
                    double grade2 = scanner.nextDouble();
                    System.out.print("科目3成绩: ");
                    double grade3 = scanner.nextDouble();
                    System.out.print("科目4成绩: ");
                    double grade4 = scanner.nextDouble();
                    scanner.nextLine(); // 清空缓冲区

                    // 存储成绩到Map
                    Map<String, Double> grades = new HashMap<>();
                    grades.put("科目1", grade1);
                    grades.put("科目2", grade2);
                    grades.put("科目3", grade3);
                    grades.put("科目4", grade4);

                    if (type == 1) {
                        System.out.print("专业: ");
                        String major = scanner.nextLine();
                        Undergraduate undergraduate = new Undergraduate(studentID, name, age, className, address, grades, major);
                        system.addStudent(undergraduate);
                    } else {
                        System.out.print("导师: ");
                        String supervisor = scanner.nextLine();
                        System.out.print("研究方向: ");
                        String researchField = scanner.nextLine();
                        Graduate graduate = new Graduate(studentID, name, age, className, address, grades, supervisor, researchField);
                        system.addStudent(graduate);
                    }
                    break;

                case 2:
                    // 删除学生
                    System.out.print("请输入学生学号：");
                    String removeID = scanner.nextLine();
                    system.removeStudent(removeID);
                    break;

                case 3:
                    // 修改学生
                    System.out.print("请输入学生学号：");
                    String modifyID = scanner.nextLine();
                    System.out.print("修改学生信息...\n");

                    // 查找学生，修改信息
                    Student studentToModify = system.searchByID(modifyID).get(0);
                    if (studentToModify != null) {
                        System.out.println("请输入新的学生姓名：");
                        studentToModify.setName(scanner.nextLine());

                        System.out.println("请输入新的年龄：");
                        studentToModify.setAge(scanner.nextInt());
                        scanner.nextLine();  // 清空缓冲区

                        System.out.println("请输入新的班级：");
                        studentToModify.setClassName(scanner.nextLine());

                        // 修改成绩
                        System.out.println("请输入4门科目的新成绩：");
                        for (String subject : studentToModify.getGrades().keySet()) {
                            System.out.print(subject + "的新成绩：");
                            double newGrade = scanner.nextDouble();
                            studentToModify.getGrades().put(subject, newGrade);
                        }
                    }
                    break;

                case 4:
                    // 查询学生
                    System.out.println("查询方式：1.按班级查询 2.按姓名查询 3.按学号查询");
                    int searchChoice = scanner.nextInt();
                    scanner.nextLine();  // 清空缓冲区

                    if (searchChoice == 1) {
                        System.out.print("请输入班级：");
                        String classSearch = scanner.nextLine();
                        List<Student> foundByClass = system.searchByClass(classSearch);
                        foundByClass.forEach(student -> System.out.println(student.getDetails()));
                    } else if (searchChoice == 2) {
                        System.out.print("请输入姓名：");
                        String nameSearch = scanner.nextLine();
                        List<Student> foundByName = system.searchByName(nameSearch);
                        foundByName.forEach(student -> System.out.println(student.getDetails()));
                    } else if (searchChoice == 3) {
                        System.out.print("请输入学号：");
                        String idSearch = scanner.nextLine();
                        List<Student> foundByID = system.searchByID(idSearch);
                        foundByID.forEach(student -> System.out.println(student.getDetails()));
                    }
                    break;

                case 5:
                    // 排序学生成绩
                    system.sortByGrades();
                    break;

                case 6:
                    // 排序学号
                    system.sortByID();
                    break;

                case 7:
                    // 查看所有学生
                    List<Student> allStudents = system.getAllStudents();
                    allStudents.forEach(student -> System.out.println(student.getDetails()));
                    break;

                case 8:
                    // 查看本科生人数
                    System.out.println("本科生人数：" + system.getUndergraduateCount());
                    break;

                case 9:
                    // 查看研究生人数
                    System.out.println("研究生人数：" + system.getGraduateCount());
                    break;

                case 10:
                    // 查看总人数
                    System.out.println("总人数：" + system.getTotalStudentCount());
                    break;

                case 11:
                    // 按单科成绩排序
                    System.out.print("请输入要排序的科目（例如：科目1，科目2，科目3，科目4）：");
                    String subject = scanner.nextLine();
                    system.sortBySubject(subject);
                    break;

                case 12:
                    // 退出系统
                    System.out.println("退出系统");
                    return;

                default:
                    System.out.println("无效输入，请重新选择！");
                    break;
            }
        }
    }
}