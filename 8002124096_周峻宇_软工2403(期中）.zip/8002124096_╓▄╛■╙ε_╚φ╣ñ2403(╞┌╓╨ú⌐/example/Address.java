package org.example;

// 地址类，存储学生的省市街道等信息
public class Address {
    private String province;
    private String city;
    private String street;
    private String doorNo;

    // 构造函数，初始化地址信息
    public Address(String province, String city, String street, String doorNo) {
        this.province = province;
        this.city = city;
        this.street = street;
        this.doorNo = doorNo;
    }

    // 获取完整的地址
    public String getAddressDetails() {
        return province + ", " + city + ", " + street + ", " + doorNo;
    }
}

