package org.example;
import java.util.Map;

public class Undergraduate extends Student {
    private String major;  // 专业

    // 构造函数，初始化本科生信息
    public Undergraduate(String studentID, String name, int age, String className, Address address, Map<String, Double> grades, String major) {
        super(studentID, name, age, className, address, grades);
        this.major = major;
    }

    // 获取本科生详细信息
    @Override
    public String getDetails() {
        StringBuilder details = new StringBuilder();
        details.append("本科生: ").append(getName())
                .append(", 专业: ").append(major)
                .append(", 地址: ").append(getAddress().getAddressDetails())
                .append(", 成绩: ");

        // 拼接成绩
        for (Map.Entry<String, Double> entry : getGrades().entrySet()) {
            details.append(entry.getKey()).append(": ").append(entry.getValue()).append(" ");
        }

        return details.toString();
    }
}