package org.example;

import org.example.Graduate;
import org.example.Student;
import org.example.Undergraduate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// 学生管理系统类，提供增、删、改、查等功能
public class StudentManagementSystem {
    private List<Student> students;

    // 构造函数，初始化学生列表
    public StudentManagementSystem() {
        students = new ArrayList<>();
    }

    // 增加学生
    public void addStudent(Student student) {
        students.add(student);
    }

    // 删除学生
    public void removeStudent(String studentID) {
        students.removeIf(student -> student.getStudentID().equals(studentID));
    }

    // 修改学生信息
    public void modifyStudent(Student student) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getStudentID().equals(student.getStudentID())) {
                students.set(i, student);
            }
        }
    }

    // 根据姓名查询学生
    public List<Student> searchByName(String name) {
        return students.stream()
                .filter(student -> student.getName().equalsIgnoreCase(name))
                .collect(Collectors.toList());
    }

    // 根据学号查询学生
    public List<Student> searchByID(String studentID) {
        return students.stream()
                .filter(student -> student.getStudentID().equals(studentID))
                .collect(Collectors.toList());
    }

    // 根据班级查询学生
    public List<Student> searchByClass(String className) {
        return students.stream()
                .filter(student -> student.getClassName().equalsIgnoreCase(className))
                .collect(Collectors.toList());
    }

    // 根据成绩排序，分开研究生和本科生
    public void sortByGrades() {
        List<Undergraduate> undergraduates = students.stream()
                .filter(student -> student instanceof Undergraduate)
                .map(student -> (Undergraduate) student)
                .collect(Collectors.toList());
        List<Graduate> graduates = students.stream()
                .filter(student -> student instanceof Graduate)
                .map(student -> (Graduate) student)
                .collect(Collectors.toList());

        undergraduates.sort((student1, student2) -> Double.compare(student2.calculateTotalGrade(), student1.calculateTotalGrade()));
        graduates.sort((student1, student2) -> Double.compare(student2.calculateTotalGrade(), student1.calculateTotalGrade()));

        System.out.println("排序后按成绩排列的本科生信息：");
        undergraduates.forEach(student -> System.out.println(student.getDetails()));

        System.out.println("排序后按成绩排列的研究生信息：");
        graduates.forEach(student -> System.out.println(student.getDetails()));
    }

    // 根据学号排序
    public void sortByID() {
        students.sort((student1, student2) -> student1.getStudentID().compareTo(student2.getStudentID()));
        // 排序后显示所有学生信息
        System.out.println("排序后按学号排列的学生信息：");
        students.forEach(student -> System.out.println(student.getDetails()));
    }

    // 根据单科成绩排序，分开研究生和本科生
    public void sortBySubject(String subject) {
        List<Undergraduate> undergraduates = students.stream()
                .filter(student -> student instanceof Undergraduate)
                .map(student -> (Undergraduate) student)
                .collect(Collectors.toList());
        List<Graduate> graduates = students.stream()
                .filter(student -> student instanceof Graduate)
                .map(student -> (Graduate) student)
                .collect(Collectors.toList());

        undergraduates.sort((student1, student2) -> {
            Double grade1 = student1.getGrades().get(subject);
            Double grade2 = student2.getGrades().get(subject);
            return Double.compare(grade2, grade1);  // 降序排列
        });
        graduates.sort((student1, student2) -> {
            Double grade1 = student1.getGrades().get(subject);
            Double grade2 = student2.getGrades().get(subject);
            return Double.compare(grade2, grade1);  // 降序排列
        });

        System.out.println("排序后按 " + subject + " 排列的本科生信息：");
        undergraduates.forEach(student -> System.out.println(student.getDetails()));

        System.out.println("排序后按 " + subject + " 排列的研究生信息：");
        graduates.forEach(student -> System.out.println(student.getDetails()));
    }

    // 获取所有学生
    public List<Student> getAllStudents() {
        return students;
    }

    // 获取本科生人数
    public int getUndergraduateCount() {
        return (int) students.stream().filter(student -> student instanceof Undergraduate).count();
    }

    // 获取研究生人数
    public int getGraduateCount() {
        return (int) students.stream().filter(student -> student instanceof Graduate).count();
    }

    // 获取所有学生总人数
    public static int getTotalStudentCount() {
        return Student.getStudentCount();
    }
}