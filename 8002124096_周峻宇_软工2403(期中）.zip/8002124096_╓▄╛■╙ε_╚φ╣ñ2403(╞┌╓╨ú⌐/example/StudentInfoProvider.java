package org.example;

// 定义接口
public interface StudentInfoProvider {
    String getDetails();
}