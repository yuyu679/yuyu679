package org.example;
import java.util.Map;

public class Graduate extends Student {
    private String supervisor;  // 导师
    private String researchField;  // 研究方向

    // 构造函数，初始化研究生信息
    public Graduate(String studentID, String name, int age, String className, Address address, Map<String, Double> grades, String supervisor, String researchField) {
        super(studentID, name, age, className, address, grades);
        this.supervisor = supervisor;
        this.researchField = researchField;
    }

    // 获取研究生详细信息
    @Override
    public String getDetails() {
        StringBuilder details = new StringBuilder();
        details.append("研究生: ").append(getName())
                .append(", 导师: ").append(supervisor)
                .append(", 研究方向: ").append(researchField)
                .append(", 地址: ").append(getAddress().getAddressDetails())
                .append(", 成绩: ");

        // 拼接成绩
        for (Map.Entry<String, Double> entry : getGrades().entrySet()) {
            details.append(entry.getKey()).append(": ").append(entry.getValue()).append(" ");
        }

        return details.toString();
    }
}