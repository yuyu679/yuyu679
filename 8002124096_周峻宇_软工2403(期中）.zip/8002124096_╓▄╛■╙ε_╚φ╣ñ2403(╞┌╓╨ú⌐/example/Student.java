package org.example;

import java.util.Map;

public abstract class Student implements StudentInfoProvider {
    private String studentID;
    private String name;
    private int age;
    private String className;
    private Address address;
    private Map<String, Double> grades;
    public static int studentCount = 0;

    // 构造函数，初始化学生信息
    public Student(String studentID, String name, int age, String className, Address address, Map<String, Double> grades) {
        this.studentID = studentID;
        this.name = name;
        this.age = age;
        this.className = className;
        this.address = address;
        this.grades = grades;
        studentCount++;  // 每次新增学生，人数加1
    }

    // 计算学生的总成绩
    public double calculateTotalGrade() {
        double total = 0;
        for (double grade : grades.values()) {
            total += grade;
        }
        return total;
    }

    // 获取学生学号
    public String getStudentID() {
        return studentID;
    }

    // 获取学生姓名
    public String getName() {
        return name;
    }

    // 设置学生姓名
    public void setName(String name) {
        this.name = name;
    }

    // 获取学生年龄
    public int getAge() {
        return age;
    }

    // 设置学生年龄
    public void setAge(int age) {
        this.age = age;
    }

    // 获取学生班级
    public String getClassName() {
        return className;
    }

    // 设置学生班级
    public void setClassName(String className) {
        this.className = className;
    }

    // 获取学生地址
    public Address getAddress() {
        return address;
    }

    // 获取学生成绩
    public Map<String, Double> getGrades() {
        return grades;
    }

    // 获取学生总数的静态方法
    public static int getStudentCount() {
        return studentCount;
    }
}